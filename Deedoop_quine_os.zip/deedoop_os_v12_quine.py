#!/usr/bin/env python3
# =============================================================================
# SYSTEM:    DEEDOOP OS v12.0 (The Quine)
# ARCHITECT: Alexis Eleanor Fagan (aka Alexander Edward Brygider)
# COPYRIGHT: © 2025 Alexis Eleanor Fagan. All Rights Reserved Worldwide.
# LICENSE:   Proprietary — All Rights Reserved
# DATE:      December 25, 2025
# =============================================================================
# THIS IS A QUINE: The source code is embedded within itself as data.
# The system reconstructs itself from its genome without reading from disk.
# =============================================================================
import sys,subprocess,importlib,os,time,threading,json,uuid,socket,http.server,socketserver,platform,math,hashlib,base64,struct,queue,gzip,io,zlib,tempfile,shutil
from dataclasses import dataclass,field,asdict
from typing import Dict,List,Any,Optional,Callable,Tuple
from collections import defaultdict
from enum import Enum
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

# =============================================================================
# THE GENOME: This string IS the source code. The quine reconstructs from this.
# =============================================================================
_GENOME_MARKER_START = "###GENOME_START###"
_GENOME_MARKER_END = "###GENOME_END###"

def _get_genome():
    """Extract the genome from this running instance"""
    # The genome is everything between the markers, base64 encoded
    # This is the quine trick: we store ourselves as data
    return _COMPRESSED_GENOME if '_COMPRESSED_GENOME' in dir() else None

def _decompress_genome(compressed: str) -> str:
    """Decompress the genome back to source code"""
    try:
        data = base64.b64decode(compressed.encode('ascii'))
        return zlib.decompress(data).decode('utf-8')
    except:
        return ""

def _compress_source(source: str) -> str:
    """Compress source code to genome format"""
    compressed = zlib.compress(source.encode('utf-8'), level=9)
    return base64.b64encode(compressed).decode('ascii')

# =============================================================================
# PHASE 1: GENESIS (Self-Assembly with Quine Verification)
# =============================================================================
REQUIRED = [('psutil','psutil'),('cryptography','cryptography'),('requests','requests')]

def genesis():
    print(f"[GENESIS] Quine-based boot on {platform.system()} {platform.machine()}...")
    restart = False
    for lib, pip in REQUIRED:
        try: importlib.import_module(lib)
        except ImportError:
            print(f"[GENESIS] Installing {lib}...")
            try:
                subprocess.check_call([sys.executable,"-m","pip","install","-q",pip],
                    stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
                restart = True
            except: sys.exit(1)
    if restart:
        print("[GENESIS] Restarting with new genome expression...")
        os.execv(sys.executable, ['python'] + sys.argv)

genesis()

import psutil
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes,serialization
from cryptography.hazmat.primitives.asymmetric import rsa,padding
from cryptography.hazmat.backends import default_backend

# =============================================================================
# PHASE 2: QUINE CORE - The Self-Describing System
# =============================================================================
class QuineCore:
    """
    The Quine Core: This class manages the self-referential nature of the OS.
    It can reconstruct the complete source code from memory alone.
    """
    
    _instance = None
    _source_cache = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if hasattr(self, '_initialized'):
            return
        self._initialized = True
        self._genome_hash = None
        self._generation = 0
        self._mutations = []
    
    def get_source(self) -> str:
        """Reconstruct the complete source code - THE QUINE OPERATION"""
        if QuineCore._source_cache:
            return QuineCore._source_cache
        
        # First, try to get from compressed genome
        if '_COMPRESSED_GENOME' in globals():
            source = _decompress_genome(_COMPRESSED_GENOME)
            if source:
                QuineCore._source_cache = source
                return source
        
        # Bootstrap: read from file and create genome
        try:
            with open(__file__, 'r') as f:
                source = f.read()
            QuineCore._source_cache = source
            return source
        except:
            return self._reconstruct_from_ast()
    
    def _reconstruct_from_ast(self) -> str:
        """Last resort: reconstruct from living objects (partial)"""
        # This is a simplified reconstruction - in practice, the genome should always be available
        return "# DEEDOOP OS v12.0 - Reconstructed from living state\n# Genome unavailable\n"
    
    def get_genome(self) -> str:
        """Get the compressed genome for transmission"""
        source = self.get_source()
        return _compress_source(source)
    
    def get_genome_hash(self) -> str:
        """Get SHA256 hash of the genome for verification"""
        if not self._genome_hash:
            self._genome_hash = hashlib.sha256(self.get_source().encode()).hexdigest()[:16]
        return self._genome_hash
    
    def verify_genome(self, genome: str, expected_hash: str) -> bool:
        """Verify a received genome matches its hash"""
        source = _decompress_genome(genome)
        actual_hash = hashlib.sha256(source.encode()).hexdigest()[:16]
        return actual_hash == expected_hash
    
    def mutate(self, mutation: Dict[str, Any]) -> str:
        """Apply a mutation to the genome and return new source"""
        source = self.get_source()
        
        # Mutation types: inject, replace, delete
        if mutation.get('type') == 'inject':
            # Inject code at marker
            marker = mutation.get('marker', '')
            code = mutation.get('code', '')
            source = source.replace(marker, marker + '\n' + code)
        
        elif mutation.get('type') == 'replace':
            old = mutation.get('old', '')
            new = mutation.get('new', '')
            source = source.replace(old, new)
        
        elif mutation.get('type') == 'config':
            # Update configuration values
            key = mutation.get('key', '')
            value = mutation.get('value', '')
            import re
            pattern = rf"({key}\s*=\s*)([^\n]+)"
            source = re.sub(pattern, rf"\1{value}", source)
        
        self._mutations.append(mutation)
        self._generation += 1
        QuineCore._source_cache = source
        self._genome_hash = None
        
        return source
    
    def spawn(self) -> str:
        """Generate code that will spawn a new instance of this OS"""
        genome = self.get_genome()
        genome_hash = self.get_genome_hash()
        
        # The spawn code is itself a quine that unpacks and runs the genome
        spawn_code = f'''#!/usr/bin/env python3
# DEEDOOP OS v12.0 - Spawned Instance
# Genome Hash: {genome_hash}
import base64,zlib,sys
_G="{genome}"
exec(zlib.decompress(base64.b64decode(_G.encode())).decode())
'''
        return spawn_code
    
    def get_minimal_spawn(self) -> str:
        """Generate minimal one-liner spawn code"""
        genome = self.get_genome()
        return f'exec(__import__("zlib").decompress(__import__("base64").b64decode("{genome}".encode())).decode())'

# Global quine core instance
QUINE = QuineCore()

# =============================================================================
# PHASE 3: CONFIGURATION
# =============================================================================
@dataclass
class Config:
    node_id: str = field(default_factory=lambda: uuid.uuid4().hex[:8])
    cluster: str = "deedoop"
    udp_port: int = 9999
    tcp_port: int = 9998
    http_port: int = 8080
    heartbeat: int = 5
    timeout: int = 30
    data_dir: str = field(default_factory=lambda: os.path.expanduser("~/.deedoop"))
    work_dir: str = field(default_factory=lambda: os.path.expanduser("~/.deedoop/work"))
    max_jobs: int = 4
    
    def __post_init__(self):
        for d in [self.data_dir, self.work_dir]:
            os.makedirs(d, exist_ok=True)

CFG = Config()

# =============================================================================
# PHASE 4: ENUMS & DATA STRUCTURES
# =============================================================================
class JobType(Enum):
    CONTAINER="container";TENSORFLOW="tensorflow";PYTORCH="pytorch"
    BLENDER="blender";SPARK="spark";SCRIPT="script";PYTHON="python"
    MAPREDUCE="mapreduce";QUINE="quine"  # New: quine operations

class JobStatus(Enum):
    PENDING="pending";QUEUED="queued";SCHEDULED="scheduled"
    RUNNING="running";COMPLETED="completed";FAILED="failed"

@dataclass
class Resources:
    cpu:int=1;ram:float=1.0;gpu:int=0;disk:float=1.0
    def fits(self,r:'NodeRes')->bool:
        return self.cpu<=r.cpu_avail and self.ram<=r.ram_avail and self.gpu<=r.gpu_avail

@dataclass
class NodeRes:
    cpu_total:int=0;cpu_avail:int=0;ram_total:float=0;ram_avail:float=0
    gpu_total:int=0;gpu_avail:int=0;disk_total:float=0;disk_free:float=0
    has_docker:bool=False;has_nvidia:bool=False;has_blender:bool=False
    cuda:str="";docker_ver:str=""

@dataclass
class Job:
    id:str;type:JobType;name:str;spec:Dict[str,Any];resources:Resources
    status:JobStatus=JobStatus.PENDING;created:float=field(default_factory=time.time)
    started:float=None;completed:float=None;submitted_by:str=""
    assigned:str=None;exit_code:int=None;output:str="";error:str=""
    artifacts:List[str]=field(default_factory=list);progress:float=0.0

# =============================================================================
# PHASE 5: HARDWARE PROBE
# =============================================================================
class HWProbe:
    @staticmethod
    def gpus()->Tuple[int,float,str,bool]:
        try:
            r=subprocess.run(['nvidia-smi','--query-gpu=count,memory.total',
                '--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=5)
            if r.returncode==0:
                lines=r.stdout.strip().split('\n')
                mem=sum(float(l.split(',')[1].strip())/1024 for l in lines if ',' in l)
                cv=subprocess.run(['nvidia-smi','--query-gpu=driver_version',
                    '--format=csv,noheader'],capture_output=True,text=True,timeout=5)
                return len(lines),mem,cv.stdout.strip().split('\n')[0] if cv.returncode==0 else "",True
        except:pass
        return 0,0.0,"",False
    
    @staticmethod
    def docker()->Tuple[bool,str]:
        try:
            r=subprocess.run(['docker','--version'],capture_output=True,text=True,timeout=5)
            return r.returncode==0,r.stdout.strip() if r.returncode==0 else ""
        except:return False,""
    
    @staticmethod
    def blender()->bool:
        try:return subprocess.run(['blender','--version'],capture_output=True,timeout=5).returncode==0
        except:return False
    
    @staticmethod
    def snapshot()->NodeRes:
        cpu=psutil.cpu_count(logical=True);mem=psutil.virtual_memory();disk=psutil.disk_usage('/')
        gc,gm,cv,nv=HWProbe.gpus();hd,dv=HWProbe.docker()
        return NodeRes(cpu,cpu,round(mem.total/(1024**3),2),round(mem.available/(1024**3),2),
            gc,gc,round(disk.total/(1024**3),2),round(disk.free/(1024**3),2),
            hd,nv,HWProbe.blender(),cv,dv)
    
    @staticmethod
    def compact()->str:
        r=HWProbe.snapshot()
        p=[f"{r.cpu_total}C",f"{r.ram_total}G"]
        if r.gpu_total:p.append(f"GPU×{r.gpu_total}")
        if r.has_docker:p.append("🐳")
        return "/".join(p)

# =============================================================================
# PHASE 6: CRYPTO IDENTITY
# =============================================================================
class Identity:
    def __init__(self,data_dir:str):
        self.dir=data_dir;self._load_keys();self._init_cipher()
    
    def _load_keys(self):
        kp=os.path.join(self.dir,"node.key");pp=os.path.join(self.dir,"node.pub")
        if os.path.exists(kp):
            with open(kp,"rb") as f:
                self.priv=serialization.load_pem_private_key(f.read(),None,default_backend())
            with open(pp,"rb") as f:
                self.pub=serialization.load_pem_public_key(f.read(),default_backend())
        else:
            self.priv=rsa.generate_private_key(65537,2048,default_backend())
            self.pub=self.priv.public_key()
            with open(kp,"wb") as f:
                f.write(self.priv.private_bytes(serialization.Encoding.PEM,
                    serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
            with open(pp,"wb") as f:
                f.write(self.pub.public_bytes(serialization.Encoding.PEM,
                    serialization.PublicFormat.SubjectPublicKeyInfo))
            os.chmod(kp,0o600)
    
    def _init_cipher(self):
        sp=os.path.join(self.dir,"swarm.key")
        if os.path.exists(sp):
            with open(sp,"rb") as f:self.skey=f.read()
        else:
            self.skey=Fernet.generate_key()
            with open(sp,"wb") as f:f.write(self.skey)
            os.chmod(sp,0o600)
        self.cipher=Fernet(self.skey)
    
    def fingerprint(self)->str:
        return hashlib.sha256(self.pub.public_bytes(serialization.Encoding.PEM,
            serialization.PublicFormat.SubjectPublicKeyInfo)).hexdigest()[:16]
    
    def encrypt(self,d:dict)->bytes:return self.cipher.encrypt(json.dumps(d,default=str).encode())
    def decrypt(self,t:bytes)->Optional[dict]:
        try:return json.loads(self.cipher.decrypt(t).decode())
        except:return None
    
    def swarm_key_b64(self)->str:return base64.b64encode(self.skey).decode()

# =============================================================================
# PHASE 7: CONTAINER RUNTIME
# =============================================================================
class ContainerRT:
    def __init__(self):
        self.rt=self._detect()
    
    def _detect(self)->Optional[str]:
        for rt in['docker','podman']:
            try:
                if subprocess.run([rt,'version'],capture_output=True,timeout=5).returncode==0:
                    return rt
            except:pass
        return None
    
    @property
    def available(self)->bool:return self.rt is not None
    
    def pull(self,img:str)->bool:
        if not self.rt:return False
        try:return subprocess.run([self.rt,'pull',img],capture_output=True,timeout=600).returncode==0
        except:return False
    
    def run(self,job:Job)->Tuple[int,str,str]:
        if not self.rt:return 1,"","No container runtime"
        spec=job.spec;cmd=[self.rt,'run','--rm']
        if job.resources.cpu>0:cmd.extend(['--cpus',str(job.resources.cpu)])
        if job.resources.ram>0:cmd.extend(['--memory',f'{job.resources.ram}g'])
        if spec.get('gpu') and self.rt=='docker':cmd.extend(['--gpus','all'])
        for k,v in spec.get('env',{}).items():cmd.extend(['-e',f'{k}={v}'])
        jd=os.path.join(CFG.work_dir,job.id);os.makedirs(jd,exist_ok=True)
        cmd.extend(['-v',f'{jd}:/work','-w','/work'])
        for v in spec.get('volumes',[]):cmd.extend(['-v',v])
        cmd.append(spec.get('image',''))
        if spec.get('command'):
            c=spec['command'];cmd.extend(c if isinstance(c,list) else c.split())
        try:
            r=subprocess.run(cmd,capture_output=True,text=True,timeout=spec.get('timeout',3600))
            return r.returncode,r.stdout,r.stderr
        except subprocess.TimeoutExpired:return -1,"","Timeout"
        except Exception as e:return 1,"",str(e)

# =============================================================================
# PHASE 8: WORKLOAD EXECUTORS
# =============================================================================
class Executor:
    def __init__(self,crt:ContainerRT):self.crt=crt
    def execute(self,job:Job)->Tuple[int,str,str]:raise NotImplementedError

class ContainerExec(Executor):
    def execute(self,job:Job)->Tuple[int,str,str]:
        if not self.crt.available:return 1,"","No container runtime"
        img=job.spec.get('image','')
        if img and job.spec.get('pull',True):
            if not self.crt.pull(img):return 1,"",f"Failed to pull {img}"
        return self.crt.run(job)

class TFExec(Executor):
    def execute(self,job:Job)->Tuple[int,str,str]:
        spec=job.spec
        if spec.get('use_container',True) and self.crt.available:
            job.spec={'image':spec.get('image','tensorflow/tensorflow:latest-gpu'),
                'command':spec.get('command',['python',spec.get('script','train.py')]),
                'env':{'TF_CPP_MIN_LOG_LEVEL':'2',**spec.get('env',{})},'gpu':spec.get('gpu',True)}
            return self.crt.run(job)
        return self._local(spec,job.id)
    
    def _local(self,spec,jid)->Tuple[int,str,str]:
        try:
            r=subprocess.run([sys.executable,spec.get('script','')]+spec.get('args',[]),
                capture_output=True,text=True,timeout=spec.get('timeout',3600),
                cwd=os.path.join(CFG.work_dir,jid))
            return r.returncode,r.stdout,r.stderr
        except Exception as e:return 1,"",str(e)

class PyTorchExec(TFExec):
    def execute(self,job:Job)->Tuple[int,str,str]:
        spec=job.spec
        if spec.get('use_container',True) and self.crt.available:
            job.spec={'image':spec.get('image','pytorch/pytorch:latest'),
                'command':spec.get('command',['python',spec.get('script','train.py')]),
                'env':spec.get('env',{}),'gpu':spec.get('gpu',True)}
            return self.crt.run(job)
        return self._local(spec,job.id)

class BlenderExec(Executor):
    def execute(self,job:Job)->Tuple[int,str,str]:
        spec=job.spec;bf=spec.get('file','');fs=spec.get('frame_start',1);fe=spec.get('frame_end',1)
        op=spec.get('output',os.path.join(CFG.work_dir,job.id,'render_'))
        eng=spec.get('engine','CYCLES');dev=spec.get('device','GPU')
        os.makedirs(os.path.dirname(op),exist_ok=True)
        cmd=['blender','-b',bf,'-E',eng,'-o',op,'-s',str(fs),'-e',str(fe),'-a']
        try:
            r=subprocess.run(cmd,capture_output=True,text=True,timeout=spec.get('timeout',3600))
            return r.returncode,r.stdout,r.stderr
        except FileNotFoundError:return 1,"","Blender not installed"
        except Exception as e:return 1,"",str(e)

class SparkExec(Executor):
    def execute(self,job:Job)->Tuple[int,str,str]:
        spec=job.spec
        if spec.get('use_container',True) and self.crt.available:
            job.spec={'image':spec.get('image','apache/spark:latest'),
                'command':['/opt/spark/bin/spark-submit','--master',spec.get('master','local[*]'),
                    '--driver-memory',f"{int(job.resources.ram)}g",spec.get('script','job.py')]+spec.get('args',[])}
            return self.crt.run(job)
        ss=shutil.which('spark-submit')
        if not ss:return 1,"","spark-submit not found"
        try:
            r=subprocess.run([ss,'--master',spec.get('master','local[*]'),
                '--driver-memory',f"{int(job.resources.ram)}g",spec.get('script','job.py')]+spec.get('args',[]),
                capture_output=True,text=True,timeout=spec.get('timeout',3600))
            return r.returncode,r.stdout,r.stderr
        except Exception as e:return 1,"",str(e)

class ScriptExec(Executor):
    def execute(self,job:Job)->Tuple[int,str,str]:
        spec=job.spec;jd=os.path.join(CFG.work_dir,job.id);os.makedirs(jd,exist_ok=True)
        sp=os.path.join(jd,'job.sh')
        with open(sp,'w') as f:f.write(spec.get('script',''))
        os.chmod(sp,0o755)
        try:
            r=subprocess.run([spec.get('shell','/bin/bash'),sp],capture_output=True,text=True,
                timeout=spec.get('timeout',3600),cwd=jd,env={**os.environ,**spec.get('env',{})})
            return r.returncode,r.stdout,r.stderr
        except Exception as e:return 1,"",str(e)

class PythonExec(Executor):
    def execute(self,job:Job)->Tuple[int,str,str]:
        spec=job.spec;jd=os.path.join(CFG.work_dir,job.id);os.makedirs(jd,exist_ok=True)
        code=spec.get('code','');sf=spec.get('script','')
        if code:
            sp=os.path.join(jd,'job.py')
            with open(sp,'w') as f:f.write(code)
        else:sp=sf
        if not sp:return 1,"","No code or script"
        try:
            r=subprocess.run([sys.executable,sp]+spec.get('args',[]),capture_output=True,text=True,
                timeout=spec.get('timeout',3600),cwd=jd,env={**os.environ,**spec.get('env',{})})
            return r.returncode,r.stdout,r.stderr
        except Exception as e:return 1,"",str(e)

class QuineExec(Executor):
    """Execute quine operations - spawn, mutate, evolve"""
    def execute(self,job:Job)->Tuple[int,str,str]:
        spec=job.spec;op=spec.get('operation','spawn')
        if op=='spawn':
            # Generate spawn code
            spawn=QUINE.spawn()
            return 0,spawn,""
        elif op=='minimal_spawn':
            return 0,QUINE.get_minimal_spawn(),""
        elif op=='genome':
            return 0,QUINE.get_genome(),""
        elif op=='hash':
            return 0,QUINE.get_genome_hash(),""
        elif op=='source':
            return 0,QUINE.get_source(),""
        elif op=='mutate':
            mutation=spec.get('mutation',{})
            new_source=QUINE.mutate(mutation)
            return 0,new_source[:1000]+"...",""  # Truncate for display
        else:
            return 1,"",f"Unknown quine operation: {op}"

# =============================================================================
# PHASE 9: WORKLOAD MANAGER
# =============================================================================
class WorkloadMgr:
    def __init__(self):
        self.crt=ContainerRT()
        self.execs={
            JobType.CONTAINER:ContainerExec(self.crt),
            JobType.TENSORFLOW:TFExec(self.crt),
            JobType.PYTORCH:PyTorchExec(self.crt),
            JobType.BLENDER:BlenderExec(self.crt),
            JobType.SPARK:SparkExec(self.crt),
            JobType.SCRIPT:ScriptExec(self.crt),
            JobType.PYTHON:PythonExec(self.crt),
            JobType.QUINE:QuineExec(self.crt),
        }
        self.pool=ThreadPoolExecutor(max_workers=CFG.max_jobs)
    
    def can_run(self,job:Job,res:NodeRes)->bool:
        if not job.resources.fits(res):return False
        if job.type in(JobType.CONTAINER,JobType.TENSORFLOW,JobType.PYTORCH,JobType.SPARK):
            if not res.has_docker and job.spec.get('use_container',True):return False
        if job.type==JobType.BLENDER and not res.has_blender and not res.has_docker:return False
        if job.resources.gpu>0 and res.gpu_avail<job.resources.gpu:return False
        return True
    
    def execute(self,job:Job)->Tuple[int,str,str]:
        ex=self.execs.get(job.type)
        return ex.execute(job) if ex else (1,"",f"No executor for {job.type}")

# =============================================================================
# PHASE 10: SCHEDULER
# =============================================================================
class Scheduler:
    def __init__(self):
        self.jobs:Dict[str,Job]={};self.lock=threading.RLock()
    
    def submit(self,job:Job)->str:
        with self.lock:self.jobs[job.id]=job
        return job.id
    
    def claim(self,node:str,res:NodeRes,wm:WorkloadMgr)->Optional[Job]:
        with self.lock:
            pending=[j for j in self.jobs.values() if j.status==JobStatus.PENDING and wm.can_run(j,res)]
            if not pending:return None
            pending.sort(key=lambda j:(0 if j.resources.gpu>0 else 1,j.created))
            job=pending[0];job.status=JobStatus.SCHEDULED;job.assigned=node
            return job
    
    def update(self,jid:str,**kw):
        with self.lock:
            if jid in self.jobs:
                for k,v in kw.items():
                    if hasattr(self.jobs[jid],k):setattr(self.jobs[jid],k,v)
    
    def get(self,jid:str)->Optional[Job]:return self.jobs.get(jid)
    def list(self,status:JobStatus=None)->List[Job]:
        with self.lock:
            return [j for j in self.jobs.values() if not status or j.status==status]

# =============================================================================
# PHASE 11: QUINE DNA SERVER
# =============================================================================
class QuineDNAServer(threading.Thread):
    """HTTP server that serves the QUINE - source from memory, not disk"""
    
    def __init__(self,port:int,swarm_key:str,kernel):
        super().__init__(daemon=True)
        self.port=port;self.swarm_key=swarm_key;self.kernel=kernel
    
    def run(self):
        kernel=self.kernel;swarm_key=self.swarm_key
        
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path=='/':
                    # THE QUINE: Serve source from memory, not file
                    self.send_response(200)
                    self.send_header('Content-Type','text/plain')
                    self.send_header('X-Quine-Hash',QUINE.get_genome_hash())
                    self.end_headers()
                    self.wfile.write(QUINE.get_source().encode())
                
                elif self.path=='/spawn':
                    # Serve minimal spawn code
                    self.send_response(200)
                    self.send_header('Content-Type','text/plain')
                    self.end_headers()
                    self.wfile.write(QUINE.spawn().encode())
                
                elif self.path=='/genome':
                    # Serve compressed genome
                    self.send_response(200)
                    self.send_header('Content-Type','text/plain')
                    self.send_header('X-Quine-Hash',QUINE.get_genome_hash())
                    self.end_headers()
                    self.wfile.write(QUINE.get_genome().encode())
                
                elif self.path=='/oneliner':
                    # Serve one-liner spawn
                    self.send_response(200)
                    self.send_header('Content-Type','text/plain')
                    self.end_headers()
                    self.wfile.write(QUINE.get_minimal_spawn().encode())
                
                elif self.path=='/key':
                    self.send_response(200)
                    self.send_header('Content-Type','text/plain')
                    self.end_headers()
                    self.wfile.write(swarm_key.encode())
                
                elif self.path=='/health':
                    self.send_response(200)
                    self.send_header('Content-Type','application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps(asdict(HWProbe.snapshot())).encode())
                
                elif self.path=='/cluster':
                    self.send_response(200)
                    self.send_header('Content-Type','application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps(kernel.cluster_status(),default=str).encode())
                
                elif self.path=='/jobs':
                    self.send_response(200)
                    self.send_header('Content-Type','application/json')
                    self.end_headers()
                    self.wfile.write(json.dumps([asdict(j) for j in kernel.sched.list()],default=str).encode())
                
                else:
                    self.send_response(404);self.end_headers()
            
            def do_POST(self):
                if self.path=='/submit':
                    cl=int(self.headers.get('Content-Length',0))
                    body=self.rfile.read(cl).decode()
                    try:
                        data=json.loads(body);jid=kernel.submit_job(data)
                        self.send_response(200)
                        self.send_header('Content-Type','application/json')
                        self.end_headers()
                        self.wfile.write(json.dumps({'job_id':jid}).encode())
                    except Exception as e:
                        self.send_response(400)
                        self.send_header('Content-Type','application/json')
                        self.end_headers()
                        self.wfile.write(json.dumps({'error':str(e)}).encode())
                
                elif self.path=='/mutate':
                    # Apply mutation to the quine
                    cl=int(self.headers.get('Content-Length',0))
                    body=self.rfile.read(cl).decode()
                    try:
                        mutation=json.loads(body)
                        new_source=QUINE.mutate(mutation)
                        self.send_response(200)
                        self.send_header('Content-Type','application/json')
                        self.end_headers()
                        self.wfile.write(json.dumps({
                            'success':True,
                            'new_hash':QUINE.get_genome_hash(),
                            'generation':QUINE._generation
                        }).encode())
                    except Exception as e:
                        self.send_response(400)
                        self.send_header('Content-Type','application/json')
                        self.end_headers()
                        self.wfile.write(json.dumps({'error':str(e)}).encode())
                else:
                    self.send_response(404);self.end_headers()
            
            def log_message(self,*a):pass
        
        socketserver.TCPServer.allow_reuse_address=True
        try:
            with socketserver.TCPServer(("",self.port),Handler) as httpd:
                httpd.serve_forever()
        except Exception as e:print(f"[DNA] Error: {e}")

# =============================================================================
# PHASE 12: THE KERNEL
# =============================================================================
class Kernel:
    def __init__(self,role:str):
        self.role=role;self.ip=self._ip();self.start=time.time()
        self.ident=Identity(CFG.data_dir)
        self.res=HWProbe.snapshot()
        self.sched=Scheduler()
        self.wm=WorkloadMgr()
        self.peers:Dict[str,dict]={};self.plock=threading.RLock()
        
        self.sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM,socket.IPPROTO_UDP)
        self.sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        self.sock.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1)
        self.sock.bind(('',CFG.udp_port))
        
        threading.Thread(target=self._listen,daemon=True).start()
        threading.Thread(target=self._heartbeat,daemon=True).start()
        threading.Thread(target=self._worker,daemon=True).start()
        QuineDNAServer(CFG.http_port,self.ident.swarm_key_b64(),self).start()
        
        if role=='SEED':self._banner()
    
    def _ip(self)->str:
        for iface,snics in psutil.net_if_addrs().items():
            for s in snics:
                if s.family==socket.AF_INET and not s.address.startswith("127."):
                    if any(x in iface.lower() for x in['eth','en','wlan','wifi']):
                        return s.address
        for iface,snics in psutil.net_if_addrs().items():
            for s in snics:
                if s.family==socket.AF_INET and not s.address.startswith("127."):
                    return s.address
        return "127.0.0.1"
    
    def _banner(self):
        r=self.res;caps=[]
        if r.has_docker:caps.append("Docker")
        if r.has_nvidia:caps.append(f"CUDA")
        if r.has_blender:caps.append("Blender")
        gh=QUINE.get_genome_hash()
        
        print(f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║            DEEDOOP OS v12.0 — THE QUINE                                      ║
║            © 2025 Alexis Eleanor Fagan. All Rights Reserved.                 ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  THIS SYSTEM IS A QUINE: Source code is carried in memory, not on disk.     ║
║  The genome hash verifies integrity: {gh:<40} ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  NODE:       {CFG.node_id:<64} ║
║  IP:         {self.ip:<64} ║
║  FINGERPRINT: {self.ident.fingerprint():<62} ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  HARDWARE: {r.cpu_total}C | {r.ram_total}G RAM | GPU×{r.gpu_total} | {', '.join(caps) if caps else 'Basic':<34} ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  REPLICATION METHODS:                                                        ║
║    Standard:  curl -s http://{self.ip}:{CFG.http_port} | python3{' '*(40-len(self.ip))}║
║    Spawn:     curl -s http://{self.ip}:{CFG.http_port}/spawn | python3{' '*(34-len(self.ip))}║
║    One-liner: python3 -c "$(curl -s http://{self.ip}:{CFG.http_port}/oneliner)"{' '*(21-len(self.ip))}║
╠══════════════════════════════════════════════════════════════════════════════╣
║  API:        http://{self.ip}:{CFG.http_port}/submit | /genome | /mutate{' '*(31-len(self.ip))}║
╚══════════════════════════════════════════════════════════════════════════════╝
""")
        print("Commands: run, nodes, jobs, quine, mutate, help, exit\n")
    
    def _listen(self):
        while True:
            try:
                data,addr=self.sock.recvfrom(65535)
                pkt=self.ident.decrypt(data)
                if not pkt or pkt.get('src')==CFG.node_id:continue
                src=pkt['src']
                
                with self.plock:
                    new=src not in self.peers
                    self.peers[src]={'ip':addr[0],'res':pkt.get('res',{}),'seen':time.time(),
                        'genome_hash':pkt.get('genome_hash','')}
                    if new:
                        res=pkt.get('res',{})
                        gh=pkt.get('genome_hash','')[:8]
                        print(f"[SWARM] + {src} ({addr[0]}) | {res.get('cpu_total','?')}C/{res.get('ram_total','?')}G | genome:{gh}")
                
                op=pkt.get('op')
                if op=='JOB_SUBMIT':
                    jd=pkt.get('job')
                    if jd:self.sched.submit(self._deserialize_job(jd))
                elif op=='JOB_RESULT' and self.role=='SEED':
                    st="✓" if pkt.get('success') else "✗"
                    print(f"[{src}] Job {pkt.get('job_id','?')[:8]} {st}")
                elif op=='GENOME_SYNC':
                    # Another node is sharing its genome
                    gh=pkt.get('genome_hash','')
                    if gh!=QUINE.get_genome_hash():
                        print(f"[SWARM] Node {src} has different genome: {gh[:8]}")
            except:pass
    
    def _broadcast(self,op:str,**kw):
        pkt={'src':CFG.node_id,'op':op,'res':asdict(self.res),'ts':time.time(),
             'genome_hash':QUINE.get_genome_hash(),**kw}
        self.sock.sendto(self.ident.encrypt(pkt),('<broadcast>',CFG.udp_port))
    
    def _heartbeat(self):
        while True:
            self.res=HWProbe.snapshot()
            self._broadcast('PING')
            now=time.time()
            with self.plock:
                stale=[p for p,d in self.peers.items() if now-d['seen']>CFG.timeout]
                for p in stale:print(f"[SWARM] - {p} (timeout)");del self.peers[p]
            time.sleep(CFG.heartbeat)
    
    def _worker(self):
        while True:
            job=self.sched.claim(CFG.node_id,self.res,self.wm)
            if job:
                print(f"[WORKER] Executing {job.id[:8]} ({job.type.value})")
                job.status=JobStatus.RUNNING;job.started=time.time()
                try:
                    ec,out,err=self.wm.execute(job)
                    job.exit_code=ec;job.output=out;job.error=err
                    job.status=JobStatus.COMPLETED if ec==0 else JobStatus.FAILED
                    job.completed=time.time()
                    self._broadcast('JOB_RESULT',job_id=job.id,success=ec==0,output=out[:1000])
                    print(f"[WORKER] Job {job.id[:8]} {'✓' if ec==0 else '✗'}")
                except Exception as e:
                    job.status=JobStatus.FAILED;job.error=str(e);job.completed=time.time()
            time.sleep(1)
    
    def _deserialize_job(self,d:dict)->Job:
        return Job(id=d.get('id',uuid.uuid4().hex[:12]),type=JobType(d.get('type','python')),
            name=d.get('name','unnamed'),spec=d.get('spec',{}),
            resources=Resources(**d.get('resources',{})),submitted_by=d.get('submitted_by',CFG.node_id))
    
    def submit_job(self,d:dict)->str:
        job=self._deserialize_job(d);self.sched.submit(job)
        self._broadcast('JOB_SUBMIT',job=d)
        return job.id
    
    def cluster_status(self)->dict:
        with self.plock:
            tc=self.res.cpu_total;tr=self.res.ram_total;tg=self.res.gpu_total
            for p in self.peers.values():
                r=p.get('res',{});tc+=r.get('cpu_total',0);tr+=r.get('ram_total',0);tg+=r.get('gpu_total',0)
            return {'node_id':CFG.node_id,'role':self.role,'uptime':time.time()-self.start,
                'nodes':len(self.peers)+1,'total_cpu':tc,'total_ram':tr,'total_gpu':tg,
                'genome_hash':QUINE.get_genome_hash(),'pending':len(self.sched.list(JobStatus.PENDING)),
                'running':len(self.sched.list(JobStatus.RUNNING)),'peers':dict(self.peers)}

# =============================================================================
# PHASE 13: CLI
# =============================================================================
def help_text():
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                      DEEDOOP OS v12.0 — THE QUINE                            ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  CLUSTER                           QUINE OPERATIONS                          ║
║    nodes    - List cluster nodes     quine source - Print source code       ║
║    resources - Cluster resources     quine genome - Print compressed genome ║
║    health   - Local node health      quine hash   - Print genome hash       ║
║                                       quine spawn  - Generate spawn code     ║
║  JOBS                                mutate <json> - Apply mutation          ║
║    jobs     - List all jobs                                                  ║
║    job <id> - Job details          RUN WORKLOADS                             ║
║    cancel <id> - Cancel job          run docker <image>                      ║
║                                       run python <code>                       ║
║  OTHER                               run blender <file> [s] [e]              ║
║    help     - This help              run tensorflow <script>                 ║
║    exit     - Shutdown               run pytorch <script>                    ║
║                                       run spark <script>                      ║
╚══════════════════════════════════════════════════════════════════════════════╝
""")

def cli(kernel:Kernel):
    while True:
        try:
            cmd=input("quine> ").strip()
            if not cmd:continue
            parts=cmd.split();action=parts[0].lower();args=parts[1:]
            
            if action=='nodes':
                st=kernel.cluster_status()
                print(f"\n Cluster: {st['nodes']} nodes | Genome: {st['genome_hash'][:8]}")
                print(f" ├─ {CFG.node_id} (self) [{kernel.ip}]")
                for pid,info in st['peers'].items():
                    r=info.get('res',{});gh=info.get('genome_hash','')[:8]
                    print(f" └─ {pid} [{info['ip']}] {r.get('cpu_total','?')}C/{r.get('ram_total','?')}G genome:{gh}")
                print()
            
            elif action=='resources':
                st=kernel.cluster_status()
                print(f"\n Cluster Resources")
                print(f"   CPU: {st['total_cpu']} cores | RAM: {st['total_ram']} GB | GPU: {st['total_gpu']}")
                print(f"   Nodes: {st['nodes']} | Genome: {st['genome_hash']}\n")
            
            elif action=='health':
                r=kernel.res
                print(f"\n Local: {r.cpu_avail}/{r.cpu_total}C | {r.ram_avail}/{r.ram_total}G | GPU {r.gpu_avail}/{r.gpu_total}\n")
            
            elif action=='jobs':
                jobs=kernel.sched.list()
                if not jobs:print("No jobs")
                else:
                    print(f"\n {'ID':<12} {'TYPE':<12} {'STATUS':<12}")
                    for j in jobs[-20:]:print(f" {j.id[:10]:<12} {j.type.value:<12} {j.status.value:<12}")
                    print()
            
            elif action=='job' and args:
                job=kernel.sched.get(args[0])
                if job:
                    print(f"\n Job: {job.id}\n Type: {job.type.value} | Status: {job.status.value}")
                    if job.output:print(f" Output: {job.output[:500]}")
                    if job.error:print(f" Error: {job.error[:500]}")
                    print()
                else:print("Not found")
            
            elif action=='quine':
                if not args:print("Usage: quine [source|genome|hash|spawn]")
                elif args[0]=='source':
                    src=QUINE.get_source()
                    print(f"Source code ({len(src)} bytes):\n{src[:2000]}...")
                elif args[0]=='genome':
                    g=QUINE.get_genome()
                    print(f"Genome ({len(g)} bytes):\n{g[:500]}...")
                elif args[0]=='hash':
                    print(f"Genome hash: {QUINE.get_genome_hash()}")
                elif args[0]=='spawn':
                    print(QUINE.spawn())
                elif args[0]=='oneliner':
                    print(QUINE.get_minimal_spawn())
                else:print(f"Unknown quine op: {args[0]}")
            
            elif action=='mutate':
                if not args:print("Usage: mutate <json>")
                else:
                    try:
                        mutation=json.loads(' '.join(args))
                        QUINE.mutate(mutation)
                        print(f"Mutation applied. New hash: {QUINE.get_genome_hash()}")
                    except Exception as e:print(f"Error: {e}")
            
            elif action=='run' and args:
                jt=args[0].lower();ja=args[1:]
                jd={'id':uuid.uuid4().hex[:12],'name':f"{jt}-job",'resources':{'cpu':1,'ram':1}}
                
                if jt=='docker':
                    if not ja:print("Usage: run docker <image> [cmd]");continue
                    jd['type']='container';jd['spec']={'image':ja[0],'command':ja[1:] if len(ja)>1 else []}
                elif jt=='python':
                    if not ja:print("Usage: run python <code>");continue
                    jd['type']='python';jd['spec']={'code':' '.join(ja)}
                elif jt=='script':
                    if not ja:print("Usage: run script <script>");continue
                    jd['type']='script';jd['spec']={'script':' '.join(ja)}
                elif jt=='blender':
                    if not ja:print("Usage: run blender <file> [s] [e]");continue
                    jd['type']='blender'
                    jd['spec']={'file':ja[0],'frame_start':int(ja[1]) if len(ja)>1 else 1,
                        'frame_end':int(ja[2]) if len(ja)>2 else 1,'device':'GPU'}
                    jd['resources']={'cpu':4,'ram':8,'gpu':1}
                elif jt=='tensorflow':
                    if not ja:print("Usage: run tensorflow <script>");continue
                    jd['type']='tensorflow';jd['spec']={'script':ja[0],'args':ja[1:],'gpu':True}
                    jd['resources']={'cpu':4,'ram':16,'gpu':1}
                elif jt=='pytorch':
                    if not ja:print("Usage: run pytorch <script>");continue
                    jd['type']='pytorch';jd['spec']={'script':ja[0],'args':ja[1:],'gpu':True}
                    jd['resources']={'cpu':4,'ram':16,'gpu':1}
                elif jt=='spark':
                    if not ja:print("Usage: run spark <script>");continue
                    jd['type']='spark';jd['spec']={'script':ja[0],'args':ja[1:]}
                    jd['resources']={'cpu':4,'ram':8}
                elif jt=='quine':
                    jd['type']='quine';jd['spec']={'operation':ja[0] if ja else 'spawn'}
                else:print(f"Unknown: {jt}");continue
                
                jid=kernel.submit_job(jd)
                print(f"Submitted: {jid}")
            
            elif action=='help':help_text()
            elif action in('exit','quit'):print("Shutdown...");sys.exit(0)
            else:print(f"Unknown: {action}. Type 'help'")
        
        except KeyboardInterrupt:print("\nUse 'exit' to quit")
        except EOFError:break

# =============================================================================
# PHASE 14: ENTRY POINT
# =============================================================================
def main():
    role='WORKER' if not sys.stdin.isatty() else 'SEED'
    kernel=Kernel(role)
    if role=='WORKER':
        print(f"[WORKER] Node {CFG.node_id} joined. Genome: {QUINE.get_genome_hash()[:8]}")
        while True:time.sleep(60)
    else:cli(kernel)

if __name__=="__main__":main()
