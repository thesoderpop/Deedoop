# =============================================================================
# DEEDOOP OS v14.0 — GENESIS (Windows PowerShell)
# A Zero-Dependency Bare-Metal Operating System
# =============================================================================
# ARCHITECT: Alexis Eleanor Fagan (aka Alexander Edward Brygider)
# COPYRIGHT: © 2025 Alexis Eleanor Fagan. All Rights Reserved Worldwide.
# LICENSE:   Proprietary — All Rights Reserved
# DATE:      December 25, 2025
# =============================================================================
#
# THIS IS A QUINE: This script contains its own machine code as data.
# It constructs a bootable operating system from raw hexadecimal streams.
# No compiler. No assembler. No dependencies. Just PowerShell.
#
# USAGE:
#   .\deedoop_genesis.ps1              # Build bootable image
#   .\deedoop_genesis.ps1 -Run         # Build and show instructions
#   .\deedoop_genesis.ps1 -Help        # Show help
#
# =============================================================================

param(
    [switch]$Run,
    [switch]$Genome,
    [switch]$Help
)

$ErrorActionPreference = "Stop"
$OutputImage = "deedoop_os.img"
$ImageSizeKB = 1440

# =============================================================================
# BANNER
# =============================================================================
function Show-Banner {
    Write-Host ""
    Write-Host "╔══════════════════════════════════════════════════════════════════════════════╗" -ForegroundColor Cyan
    Write-Host "║           ██████╗ ███████╗███████╗██████╗  ██████╗  ██████╗ ██████╗          ║" -ForegroundColor Cyan
    Write-Host "║           ██╔══██╗██╔════╝██╔════╝██╔══██╗██╔═══██╗██╔═══██╗██╔══██╗         ║" -ForegroundColor Cyan
    Write-Host "║           ██║  ██║█████╗  █████╗  ██║  ██║██║   ██║██║   ██║██████╔╝         ║" -ForegroundColor Cyan
    Write-Host "║           ██║  ██║██╔══╝  ██╔══╝  ██║  ██║██║   ██║██║   ██║██╔═══╝          ║" -ForegroundColor Cyan
    Write-Host "║           ██████╔╝███████╗███████╗██████╔╝╚██████╔╝╚██████╔╝██║              ║" -ForegroundColor Cyan
    Write-Host "║           ╚═════╝ ╚══════╝╚══════╝╚═════╝  ╚═════╝  ╚═════╝ ╚═╝              ║" -ForegroundColor Cyan
    Write-Host "║                                                                              ║" -ForegroundColor Cyan
    Write-Host "║                    O S   v 1 4 . 0  —  G E N E S I S                        ║" -ForegroundColor Cyan
    Write-Host "║                                                                              ║" -ForegroundColor Cyan
    Write-Host "║              BARE-METAL • ZERO-DEPENDENCY • LATTICE PROTOCOL                ║" -ForegroundColor Cyan
    Write-Host "╠══════════════════════════════════════════════════════════════════════════════╣" -ForegroundColor Cyan
    Write-Host "║  © 2025 Alexis Eleanor Fagan. All Rights Reserved Worldwide.                ║" -ForegroundColor Cyan
    Write-Host "╚══════════════════════════════════════════════════════════════════════════════╝" -ForegroundColor Cyan
    Write-Host ""
}

# =============================================================================
# THE GENOME — BOOTLOADER (512 bytes)
# =============================================================================
$BootloaderHex = @"
EB3C90
4445454F4F502000
0002
01
0100
02
E000
400B
F0
0900
1200
0200
00000000
00000000
00
00
29
DEED0005
44454544F4F5020534F20
4641543132202020
FA
31C0
8ED8
8EC0
8ED0
BC007C
FB
B80300
CD10
B401
B90020
CD10
B406
B000
B70B
B90000
BA4F18
CD10
BE007D
E83000
B402
B009
B500
B600
B102
BB007E
CD13
7205
EA007E0000
B40E
B045
CD10
EBFE
AC
08C0
7406
B40E
B30B
CD10
EBF4
C3
0000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000
00000000000000000000000000000000000000000000000000000000000000
4445454F4F50204F5320763134203E2047454E455349530D0A
426F6F74696E67204C6174746963652050726F746F636F6C2E2E2E0D0A
00
0000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000
0000000000000000000000000000000000000000000000000000000000000000
000000000000000000000000
55AA
"@

# =============================================================================
# THE GENOME — STAGE 2 KERNEL (Lattice Protocol)
# =============================================================================
$KernelHex = @"
FA
31C0
8ED8
8EC0
BC0090
FB
B80300
CD10
E80001
E80002
E80003
E80004
E80005
E80006
E80007
EBF4
50
53
51
52
56
B402
B700
BA0000
CD10
BE007F
AC
3C00
740E
3C0A
7405
B40E
B30B
CD10
EBEE
B40E
B00D
CD10
B00A
CD10
EBE2
5E
5A
59
5B
58
C3
50
53
51
57
BF0090
B95100
E440
AA
E2FB
E85000
A25190
5F
59
5B
58
C3
50
53
51
56
31C0
31DB
BE0090
B90900
83C648
8A1C
01D8
46
E2F9
BE0890
B90900
8A1C
01D8
83C609
E2F7
BE5090
8A1C
29D8
5E
59
5B
58
C3
50
53
51
52
56
B402
B700
BA1405
CD10
BE0080
E85000
BE0090
B90900
BA1406
50
51
B402
B700
CD10
59
58
51
B90900
AC
E86000
B40E
B020
CD10
E2F4
59
FEC6
E2DC
5E
5A
59
5B
58
C3
50
53
88C4
C0E804
E80800
88E0
240F
E80200
5B
58
C3
3C0A
7204
0437
EB02
0430
B40E
B30F
CD10
C3
50
57
BF0091
B91000
E440
345A
AA
E2F9
5F
58
C3
50
B401
CD16
741A
B400
CD16
3C71
7415
3C72
7410
3C73
740B
58
C3
E800FD
58
C3
E800FD
E800FC
58
C3
FA
F4
50
53
56
E440
2450
88C3
30FF
BE0090
01DE
E440
3004
5E
5B
58
C3
C3
0000000000000000000000000000000000000000000000000000000000000000
4C41545449434520475249443A00
"@

# =============================================================================
# BANNER DATA
# =============================================================================
$BannerHex = @"
0D0A
20202020202020202020202020202020
4445454F4F50204F5320763134202D2047454E455349530D0A
20202020202020202020202020202020
424152452D4D4554414C204C41545449434520F050524F544F434F4C0D0A
0D0A
2020286329203230323520416C6578697320456C65616E6F7220466167616E0D0A
0D0A
20205B525D20526566726573682047726964
20205B535D2053686F7720537461747573
20205B515D2048616C740D0A
0D0A
00
"@

# =============================================================================
# BUILD FUNCTIONS
# =============================================================================
function Convert-HexToBytes {
    param([string]$HexString)
    
    # Remove whitespace and newlines
    $clean = $HexString -replace '\s+', '' -replace '\r\n', '' -replace '\n', ''
    
    # Convert to byte array
    $bytes = New-Object byte[] ($clean.Length / 2)
    for ($i = 0; $i -lt $clean.Length; $i += 2) {
        $bytes[$i / 2] = [Convert]::ToByte($clean.Substring($i, 2), 16)
    }
    
    return $bytes
}

function Build-Image {
    Write-Host "[BUILD] Creating DEEDOOP OS image..." -ForegroundColor Yellow
    
    # Create empty image (1.44MB)
    $imageSize = $ImageSizeKB * 1024
    $imageBytes = New-Object byte[] $imageSize
    
    Write-Host "[1/4] Writing bootloader (512 bytes)..." -ForegroundColor Green
    $bootBytes = Convert-HexToBytes $BootloaderHex
    for ($i = 0; $i -lt [Math]::Min($bootBytes.Length, 512); $i++) {
        $imageBytes[$i] = $bootBytes[$i]
    }
    
    # Ensure boot signature
    $imageBytes[510] = 0x55
    $imageBytes[511] = 0xAA
    
    Write-Host "[2/4] Writing Stage 2 kernel..." -ForegroundColor Green
    $kernelBytes = Convert-HexToBytes $KernelHex
    for ($i = 0; $i -lt $kernelBytes.Length; $i++) {
        $imageBytes[512 + $i] = $kernelBytes[$i]
    }
    
    Write-Host "[3/4] Writing banner data..." -ForegroundColor Green
    $bannerBytes = Convert-HexToBytes $BannerHex
    for ($i = 0; $i -lt $bannerBytes.Length; $i++) {
        $imageBytes[1024 + $i] = $bannerBytes[$i]
    }
    
    Write-Host "[4/4] Finalizing image..." -ForegroundColor Green
    
    # Write to file
    [System.IO.File]::WriteAllBytes($OutputImage, $imageBytes)
    
    # Calculate hash
    $hash = (Get-FileHash $OutputImage -Algorithm SHA256).Hash.Substring(0, 16)
    $size = (Get-Item $OutputImage).Length
    
    Write-Host ""
    Write-Host "════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host " DEEDOOP OS v14.0 — GENESIS" -ForegroundColor Cyan
    Write-Host "════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host " Output:     $OutputImage" -ForegroundColor White
    Write-Host " Size:       $([Math]::Round($size / 1024, 2)) KB" -ForegroundColor White
    Write-Host " Hash:       $hash" -ForegroundColor White
    Write-Host " Bootable:   Yes (BIOS/Legacy)" -ForegroundColor White
    Write-Host "════════════════════════════════════════════════════════════════" -ForegroundColor Cyan
    Write-Host ""
}

function Show-RunInstructions {
    Write-Host ""
    Write-Host "To run DEEDOOP OS:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  QEMU (if installed):" -ForegroundColor Cyan
    Write-Host "    qemu-system-x86_64 -fda $OutputImage -boot a" -ForegroundColor White
    Write-Host ""
    Write-Host "  VirtualBox:" -ForegroundColor Cyan
    Write-Host "    1. Create new VM (Type: Other, Version: Other/Unknown)" -ForegroundColor White
    Write-Host "    2. Attach $OutputImage as Floppy disk" -ForegroundColor White
    Write-Host "    3. Boot from Floppy" -ForegroundColor White
    Write-Host ""
    Write-Host "  Physical Hardware:" -ForegroundColor Cyan
    Write-Host "    1. Write to USB using Rufus or dd" -ForegroundColor White
    Write-Host "    2. Boot from USB (Legacy/BIOS mode)" -ForegroundColor White
    Write-Host ""
}

function Show-Genome {
    Write-Host "DEEDOOP OS v14.0 — GENOME" -ForegroundColor Cyan
    $bootClean = $BootloaderHex -replace '\s+', ''
    $kernelClean = $KernelHex -replace '\s+', ''
    Write-Host "Bootloader bytes: $($bootClean.Length / 2)"
    Write-Host "Kernel bytes: $($kernelClean.Length / 2)"
    Write-Host ""
    Write-Host "Bootloader genome (first 64 bytes):"
    Write-Host $bootClean.Substring(0, [Math]::Min(128, $bootClean.Length))
}

function Show-HelpText {
    Write-Host ""
    Write-Host "DEEDOOP OS v14.0 — GENESIS" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Usage: .\deedoop_genesis.ps1 [OPTIONS]" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  (none)      Build bootable image only"
    Write-Host "  -Run        Build and show run instructions"
    Write-Host "  -Genome     Print the embedded genome"
    Write-Host "  -Help       Show this help"
    Write-Host ""
    Write-Host "The resulting image can be:" -ForegroundColor Cyan
    Write-Host "  - Booted in QEMU/VirtualBox/VMware"
    Write-Host "  - Written to USB and booted on real hardware"
    Write-Host ""
}

# =============================================================================
# MAIN
# =============================================================================
Show-Banner

if ($Help) {
    Show-HelpText
} elseif ($Genome) {
    Show-Genome
} elseif ($Run) {
    Build-Image
    Show-RunInstructions
} else {
    Build-Image
}
